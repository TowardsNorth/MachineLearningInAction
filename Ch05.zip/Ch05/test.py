
from numpy import *

b=array([2,8])
a=range(10)
print (len(a))


for i in range(10):
    print (i)