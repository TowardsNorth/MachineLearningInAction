This folder contains the code used to create the plots in the examples.  
The code is not very difficult, however I never meant for it to go out to readers. 
 It�s not the cleanest code nor very well documented.  Most of the time I threw 
together a dirty hack to make the plots look right, with no thoughts about 
efficiency or readability.   I�m providing it as-is, if you have a question on 
how it works or why I did something please ask, I will be more than happy to answer 
any questions.  
Peter Harrington
